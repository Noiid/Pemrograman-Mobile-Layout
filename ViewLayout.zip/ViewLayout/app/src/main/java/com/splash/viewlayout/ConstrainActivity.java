package com.splash.viewlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ConstrainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_constrain);
    }
}
